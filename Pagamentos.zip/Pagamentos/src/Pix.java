// Classe Pix
public class Pix extends Pagamento {
    private boolean comprovanteTransacaoPix;

    public Pix(String dataHoraPagamento, int numeroPagamento, double valorPago, boolean comprovanteTransacaoPix) {
        super(dataHoraPagamento, numeroPagamento, valorPago);
        this.comprovanteTransacaoPix = comprovanteTransacaoPix;
    }
    public boolean isComprovanteTransacaoPix() {
        return comprovanteTransacaoPix;
    }

    public void setComprovanteTransacaoPix(boolean comprovanteTransacaoPix) {
        this.comprovanteTransacaoPix = comprovanteTransacaoPix;
    }

    @Override
    public String imprimirCupomFiscal() {
        // Implemente a lógica para imprimir o cupom fiscal de um pagamento via Pix
        return "Cupom fiscal para pagamento via Pix";
    }
    public String imprimirCupomFiscal() {
        return "Data e Hora do Pagamento: " + dataHoraPagamento +
                "\nNúmero do Pagamento: " + numeroPagamento +
                "\nValor Pago: " + valorPago +
                "\nComprovante de Transação Pix: " + comprovanteTransacaoPix;
    }
}



}
