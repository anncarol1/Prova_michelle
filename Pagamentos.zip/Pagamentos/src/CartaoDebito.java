// Classe CartaoDebito

public class CartaoDebito extends Pagamento {
    private String numCartao;
    private String titularCartao;

    public CartaoDebito(String dataHoraPagamento, int numeroPagamento, double valorPago, String numCartao, String titularCartao) {
        super(dataHoraPagamento, numeroPagamento, valorPago);
        this.numCartao = numCartao;
        this.titularCartao = titularCartao;
    }
    public String getNumCartao() {
        return numCartao;
    }

    public void setNumCartao(String numCartao) {
        this.numCartao = numCartao;
    }

    public String getTitularCartao() {
        return titularCartao;
    }

    public void setTitularCartao(String titularCartao) {
        this.titularCartao = titularCartao;
    }
    @Override
    public String imprimirCupomFiscal() {
        // Implemente a lógica para imprimir o cupom fiscal de um pagamento com cartão de débito
        return "Cupom fiscal para pagamento com cartão de débito";
    }

    @Override
    public String imprimirCupomFiscal() {
        return "Data e Hora do Pagamento: " + dataHoraPagamento +
                "\nNúmero do Pagamento: " + numeroPagamento +
                "\nValor Pago: " + valorPago +
                "\nNúmero do Cartão: " + numCartao +
                "\nTitular do Cartão: " + titularCartao;
    }
    public class Main {
        public static void main(String[] args) {
            // Criando um objeto CartaoCredito com dados fictícios
            CartaoCredito cartaoCredito = new CartaoCredito(
                    "2023-10-05T15:30:00",   // dataHoraPagamento
                    12345,                  // numeroPagamento
                    100.50,                 // valorPago
                    "1111-2222-3333-4444",  // numCartao
                    "Visa",                 // bandeiraCartao
                    "Fulano de Tal"         // titularCartao
            );

            // Executando o método imprimirCupomFiscal()
            String cupomFiscal = cartaoCredito.imprimirCupomFiscal();

            // Exibindo o cupom fiscal
            System.out.println(cupomFiscal);
        }
    }

}
