public class Main {
    public static void main(String[] args) {
        // Criando um objeto CartaoCredito com dados fictícios
        CartaoCredito cartaoCredito = new CartaoCredito(
                "2023-10-05T15:30:00",   // dataHoraPagamento
                12345,                  // numeroPagamento
                100.50,                 // valorPago
                "1111-2222-3333-4444",  // numCartao
                "Visa",                 // bandeiraCartao
                "Fulano de Tal"         // titularCartao
        );

        // Executando o método imprimirCupomFiscal()
        String cupomFiscal = cartaoCredito.imprimirCupomFiscal();

        // Exibindo o cupom fiscal
        System.out.println(cupomFiscal);
        Pix pix = new Pix(
                "2023-10-05T15:45:00",   // dataHoraPagamento
                54321,                  // numeroPagamento
                150.75,                 // valorPago
                true                    // comprovanteTransacaoPix
        );
        public class Main {
            public static void main(String[] args) {
                // Criando um objeto CartaoDebito com dados fictícios
                CartaoDebito cartaoDebito = new CartaoDebito(
                        "2023-10-05T16:00:00",   // dataHoraPagamento
                        67890,                  // numeroPagamento
                        200.25,                 // valorPago
                        "5555-6666-7777-8888",  // numCartao
                        "Ciclano de Tal"        // titularCartao
                );

                // Executando o método imprimirCupomFiscal()
                String cupomFiscal = cartaoDebito.imprimirCupomFiscal();

                // Exibindo o cupom fiscal
                System.out.println(cupomFiscal);
            }
        }


    }
    }



