// Classe CartaoCredito
public class CartaoCredito extends Pagamento {
    private String numCartao;
    private String bandeiraCartao;
    private String titularCartao;

    public CartaoCredito(String dataHoraPagamento, int numeroPagamento, double valorPago, String numCartao, String bandeiraCartao, String titularCartao) {
        super(dataHoraPagamento, numeroPagamento, valorPago);
        this.numCartao = numCartao;
        this.bandeiraCartao = bandeiraCartao;
        this.titularCartao = titularCartao;
    }

    public String getDataHoraPagamento() {
        return dataHoraPagamento;
    }

    public void setDataHoraPagamento(String dataHoraPagamento) {
        this.dataHoraPagamento = dataHoraPagamento;
    }

    public int getNumeroPagamento() {
        return numeroPagamento;
    }

    public void setNumeroPagamento(int numeroPagamento) {
        this.numeroPagamento = numeroPagamento;
    }

    public double getValorPago() {
        return valorPago;
    }

    public void setValorPago(double valorPago) {
        this.valorPago = valorPago;
    }

    public String imprimirCupomFiscal() {
        // Implemente a lógica para imprimir o cupom fiscal de um pagamento com cartão de crédito
        return "Cupom fiscal para pagamento com cartão de crédito";
    }

    public String imprimirCupomFiscal() {
        return "Data e Hora do Pagamento: " + dataHoraPagamento +
                "\nNúmero do Pagamento: " + numeroPagamento +
                "\nValor Pago: " + valorPago +
                "\nNúmero do Cartão: " + numCartao +
                "\nBandeira do Cartão: " + bandeiraCartao +
                "\nTitular do Cartão: " + titularCartao;
    }
}














}
