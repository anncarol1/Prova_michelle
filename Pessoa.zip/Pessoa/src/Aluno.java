public class Aluno extends Pessoa {
    private int periodo;
    private int turma;

    public Aluno(int periodo, int turma) {
        this.periodo = periodo;
        this.turma = turma;
    }

    public Aluno(String nome, String email, String senha, int periodo, int turma) {
        super(nome, email, senha);
        this.periodo = periodo;
        this.turma = turma;
    }

    public String mostraAluno() {
        return "Nome: " + nome +
                "\nE-mail: " + email +
                "\nPeríodo: " + periodo +
                "\nTurma: " + turma;
    }
}