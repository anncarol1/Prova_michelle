public class Main {
    public static void main(String[] args) {
        // Criando um objeto Professor com dados fictícios
        Professor professor = new Professor(
                "João da Silva",      // nome
                "joao@gmail.com",    // email
                "senha123",          // senha
                30.5f,               // salarioHora
                20                   // horasAula
        );

        // Executando o método mostraProfessor()
        String dadosProfessor = professor.mostraProfessor();

        // Exibindo os dados do professor
        System.out.println(dadosProfessor);
    }

 {
        // Criando um objeto Aluno com dados fictícios
        Aluno aluno = new Aluno(
                "Maria da Silva",    // nome
                "maria@gmail.com",   // email
                "senha456",          // senha
                3,                   // periodo
                1                    // turma
        );

        // Executando o método mostraAluno()
        String dadosAluno = aluno.mostraAluno();

        // Exibindo os dados do aluno
        System.out.println(dadosAluno);
    }
}
